Bundled loader: attribution, licenses and corresponding source
=============================================================

These materials accompany the unchanged files from the official BepInEx
Unity IL2CPP Windows x64 build 6.0.0-be.791+b782da4, dated 23 October 2026.
The original archive contained no standalone LICENSE or THIRD-PARTY-NOTICES
files. This directory supplies the primary-source notices and source materials
identified for that archive's components. No loader binaries were changed by
this notices audit.

Original archive:
https://builds.bepinex.dev/projects/bepinex_be/791/BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.791+b782da4.zip
Archive size: 34336890 bytes
SHA256: bb1c510909b69522733791f3a0817a487379a52da6468a492f1c9c19b3ec6f9a
Build source commit: b782da4ac54e1072d2857f4a2f77c80c3ef08005
Official project: https://github.com/BepInEx/BepInEx

Corresponding source supplied here
---------------------------------
1. Source/BepInEx/
   Exact open-source files from the build commit, including project files and
   build scripts. The three proprietary Unity reference DLLs under
   Runtimes/Unity/BepInEx.Unity.IL2CPP/lib/ were excluded without downloading
   them. They are external compiler inputs, not BepInEx source code.
   Source/BepInEx/EXTERNAL_BUILD_INPUTS.txt documents their exact paths.
   BepInEx-source-tree.json records all included paths and the omissions.
   License: LGPL 2.1; see BepInEx-LICENSE.txt.

2. Source/Doorstop/
   Exact UnityDoorstop source at commit
   1c3ece1f1e6c20f4aa74d5402baabf8a0098d282 (release v4.6.0).
   BepInEx's build script specifies this release; .doorstop_version in the
   binary archive independently records 4.6.0.
   Source: https://github.com/NeighTools/UnityDoorstop/tree/1c3ece1f1e6c20f4aa74d5402baabf8a0098d282
   License: LGPL 2.1; see Doorstop-LICENSE.txt.

3. Source/Il2CppInterop-1.5.3/
   Exact release source at commit
   dbda1cb353b0f4253345dc45136d170b9e50a5a0.
   This supplies source for the unchanged Il2CppInterop.Generator.dll.
   It is intentionally distinct from the separately supplied PR291 source
   used to build this mod bundle's replacement interoperability runtime.
   Source: https://github.com/BepInEx/Il2CppInterop/tree/dbda1cb353b0f4253345dc45136d170b9e50a5a0
   License: LGPL 3, incorporating GPL 3; the full combined text is in
   Il2CppInterop-Generator-LICENSE.txt.

The separate interoperability compatibility distribution contains the source,
license and build instructions for the replaced Runtime/Common/HarmonySupport
DLLs and the added TerraFX DLL. Those materials are not duplicated here.

Other bundled components
------------------------
The exact DLL assembly metadata is retained in DEPENDENCY_METADATA.txt.
LICENSE_SOURCES.json records pinned primary-source license URLs.

HarmonyX 2.10.2 (0Harmony.dll)
  BepInEx contributors. MIT. HarmonyX-LICENSE.txt.
  https://github.com/BepInEx/HarmonyX/tree/v2.10.2

AsmResolver 6.0.0-beta.5
  Washi and contributors. MIT. AsmResolver-LICENSE.txt.
  Commit 124e161a9bc0ebb83b4d97276ae3da3c9cfe2fc5.
  https://github.com/Washi1337/AsmResolver

AssetRipper.CIL 1.2.2
  ds5678 and contributors. MIT. AssetRipper-CIL-LICENSE.txt.
  Commit 06216e69825ccd6536dc17e9ca81c4d539ce9321.
  https://github.com/AssetRipper/AssetRipper.CIL

AssetRipper.Primitives 3.2.0
  ds5678 and contributors. MIT. AssetRipper-Primitives-LICENSE.txt.
  Includes upstream uTinyRipper attribution to mafaca; its separate MIT text
  is preserved in AssetRipper-Primitives-uTinyRipper-LICENSE.txt.
  Commit d759b3db98bf2a1cb8c2181faf5d405610aac585.
  https://github.com/AssetRipper/AssetRipper.Primitives

Cpp2IL, LibCpp2IL, StableNameDotNet and WasmDisassembler
  Sam Byass and contributors. MIT. Cpp2IL-LICENSE.txt.
  Cpp2IL development.1452, commit 558ddd98642010897d54316b51fbaa7889fda093.
  https://github.com/SamboyCoding/Cpp2IL

Disarm master.99
  Sam Byass and contributors. MIT. Disarm-LICENSE.txt.
  Commit 8574010015c8c56bb7faad7e407c50b0abe9cc72.
  https://github.com/SamboyCoding/Disarm

Gee.External.Capstone 2.3.2
  Ahmed Garhy. MIT. Capstone-NET-LICENSE.txt.
  Commit b90e380c14e857865c94a355954236e678bd557c.
  https://github.com/9ee1/Capstone.NET

Iced 1.21.0
  Iced project and contributors. MIT. Iced-LICENSE.txt.
  Commit 601c40570d6c986c8e1a6a2e483dd2fdf5ade552.
  https://github.com/icedland/iced

Mono.Cecil 0.11.4 and its Mdb/Pdb/Rocks components
  Jb Evain, Novell and contributors. MIT. Mono-Cecil-LICENSE.txt.
  https://github.com/jbevain/cecil/tree/0.11.4

MonoMod.RuntimeDetour and MonoMod.Utils 22.07.31.01
  0x0ade and contributors. MIT. MonoMod-2022-LICENSE.txt.
  https://github.com/MonoMod/MonoMod/tree/v22.07.31.01

MonoMod.Backports 1.1.2 and MonoMod.ILHelpers 1.1.0
  0x0ade, DaNike and contributors. MIT. MonoMod-2024-LICENSE.txt.
  Commit a1b82852b2574742776af08818487b90b0bfab93.
  https://github.com/MonoMod/MonoMod

SemanticVersioning 2.0.2
  Adam Reeve. MIT. SemanticVersioning-LICENSE.txt.
  Commit c52c9d4c5d34a6a3bb6ff45f7276d8b6e951a42d.
  https://github.com/adamreeve/semver.net

Dobby 1.0.5
  Dobby contributors and the BepInEx fork contributors.
  Apache 2.0. Dobby-LICENSE.txt. No NOTICE file was present in this source tree.
  BepInEx's exact build script specifies release v1.0.5, which resolves to
  commit 888d971214900374edbca6206fad6ded8a2c1311.
  https://github.com/BepInEx/Dobby/tree/v1.0.5

Bundled .NET runtime and Microsoft libraries
--------------------------------------------
The bundled runtime is the BepInEx mini-coreclr 6.0.7 release. Its fork source
is commit e10df436edd020835a630a40796ba48222acb1d5; the runtime's .version file
records upstream Microsoft runtime commit 0ec02c8c96e2eda06dc5b5edfdbdba0f36415082.
The exact fork's LICENSE.TXT and THIRD-PARTY-NOTICES.TXT are supplied in dotnet/.
See dotnet/PROVENANCE.txt for the checked version evidence, release URL and
source URLs. The Microsoft extension libraries use the same MIT licensing.

Hashes and scope
----------------
MANIFEST.json supplies hashes of these notices and expanded source files.
EXPANDED_SOURCE.json records original archive names, sizes, checksums and the
byte-for-byte extraction map. The corresponding source is included as regular
files so no nested archives need to be extracted.
This directory contains no game executable, game data, save data, game-derived
wrappers, or proprietary Unity reference binaries. Retain these materials and
the separate compatibility-source materials alongside the redistributed loader.
