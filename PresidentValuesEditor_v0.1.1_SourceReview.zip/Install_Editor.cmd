@echo off
setlocal
title President Simulator - Install Values Editor
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Manage_Editor.ps1" -Action Install %*
set "president_editor_result=%errorlevel%"
echo.
pause
exit /b %president_editor_result%
