#requires -Version 5.1
# Shared helpers for the President Simulator Values Editor installer.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:TargetAppId = '3705900'
$script:TargetBuildId = '26325310'
$script:ExpectedGameHash = '0A181872756862446B3E9D8A36BFFB6A8873849FF3AC795F54AF2C31CC2C30AE'
$script:ExpectedMetadataHash = 'F751CC755DEF26E6CA81E84235091A04D5C019329FABBADEA274965E79D1377E'
$script:ProductId = 'PresidentSimulatorValuesEditor'
$script:InstallRecordName = 'PresidentValuesEditor.install.json'
$script:DisabledProxyName = 'winhttp.dll.president-values-editor-disabled'

function Get-FolderPath {
    param([string]$Path)
    $full = [IO.Path]::GetFullPath($Path)
    $root = [IO.Path]::GetPathRoot($full)
    if ($full.Length -gt $root.Length) { return $full.TrimEnd([char[]]'/\') }
    return $full
}

function Test-UnlinkedPath {
    param([string]$Path)
    try {
        $scan = [IO.Path]::GetFullPath($Path)
        while ($scan) {
            $item = Get-Item -LiteralPath $scan -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }
            $next = Split-Path -Path $scan -Parent
            if (!$next -or $next -eq $scan) { break }
            $scan = $next
        }
        return $true
    } catch { return $false }
}

function Get-VdfValue {
    param([string]$Text, [string]$Key)
    $match = [regex]::Match($Text, '(?m)^\s*"' + [regex]::Escape($Key) + '"\s*"([^"\r\n]*)"')
    if ($match.Success) { return $match.Groups[1].Value }
    return ''
}

function Get-SteamManifest {
    param([string]$Path)
    if (!(Test-UnlinkedPath $Path)) { return $null }
    $file = Get-Item -LiteralPath $Path
    if ($file.PSIsContainer -or $file.Length -gt 1MB) { return $null }
    $text = [IO.File]::ReadAllText($Path)
    if ((Get-VdfValue $text 'appid') -ne $script:TargetAppId) { return $null }
    $leaf = Get-VdfValue $text 'installdir'
    if (!$leaf -or $leaf -eq '.' -or $leaf -eq '..' -or $leaf -match '[/\\:]' -or
        $leaf.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) { return $null }
    return [pscustomobject]@{ BuildId = Get-VdfValue $text 'buildid'; InstallFolder = $leaf }
}

function Find-SteamGames {
    $roots = New-Object 'System.Collections.Generic.List[string]'
    foreach ($entry in @(@('HKCU:\Software\Valve\Steam','SteamPath'),
                          @('HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','InstallPath'),
                          @('HKLM:\SOFTWARE\Valve\Steam','InstallPath'))) {
        try {
            $row = Get-ItemProperty -LiteralPath $entry[0] -Name $entry[1] -ErrorAction Stop
            if ($row.($entry[1])) { $roots.Add([string]$row.($entry[1])) }
        } catch { }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { $roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = New-Object 'System.Collections.Generic.List[string]'
    foreach ($root in @($roots | Select-Object -Unique)) {
        if (!(Test-UnlinkedPath $root)) { continue }
        $libraries.Add($root)
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (!(Test-UnlinkedPath $vdf)) { continue }
        try {
            if ((Get-Item -LiteralPath $vdf).Length -gt 4MB) { continue }
            foreach ($match in [regex]::Matches([IO.File]::ReadAllText($vdf), '(?m)^\s*"(?:path|\d+)"\s*"([^"\r\n]+)"')) {
                $path = $match.Groups[1].Value.Replace('\\','\')
                if ([IO.Path]::IsPathRooted($path) -and (Test-UnlinkedPath $path)) { $libraries.Add($path) }
            }
        } catch { }
    }
    $seen = @{}
    foreach ($library in @($libraries | Select-Object -Unique)) {
        try {
            $manifest = Get-SteamManifest (Join-Path $library ('steamapps/appmanifest_' + $script:TargetAppId + '.acf'))
            if ($null -eq $manifest) { continue }
            $path = Get-FolderPath (Join-Path (Join-Path $library 'steamapps/common') $manifest.InstallFolder)
            if ((Test-UnlinkedPath $path) -and (Test-Path -LiteralPath (Join-Path $path 'PresidentSim.exe') -PathType Leaf) -and !$seen.ContainsKey($path)) {
                $seen[$path] = $true
                $path
            }
        } catch { }
    }
}

function Get-SelectedGamePath {
    param([string]$SuppliedPath)
    $chosen = $SuppliedPath
    if (!$chosen) {
        $games = @(Find-SteamGames)
        if ($games.Count -eq 1) { $chosen = $games[0] }
        elseif ($games.Count -gt 1) {
            for ($i=0; $i -lt $games.Count; $i++) { Write-Host ('{0}. {1}' -f ($i+1),$games[$i]) }
            $answer = Read-Host 'Choose the installation number'
            $number = 0
            if (![int]::TryParse($answer,[ref]$number) -or $number -lt 1 -or $number -gt $games.Count) { throw 'No valid installation selected.' }
            $chosen = $games[$number-1]
        } else {
            Write-Host 'In Steam: right-click President Simulator > Manage > Browse local files.'
            $chosen = Read-Host 'Paste the folder address and press Enter'
        }
    }
    if (!$chosen) { throw 'No game folder was supplied.' }
    $chosen = Get-FolderPath ($chosen.Trim().Trim([char]'"'))
    if (!(Test-UnlinkedPath $chosen) -or !(Test-UnlinkedPath (Join-Path $chosen 'PresidentSim.exe'))) {
        throw 'Select the actual, readable President Simulator game folder, not a linked folder.'
    }
    return $chosen
}

function Assert-GameClosed {
    $running = @(Get-Process -Name 'PresidentSim' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) { throw 'Close President Simulator before continuing. The installer will not close it for you.' }
}

function Assert-CompatibleGame {
    param([string]$GameRoot)
    $steamApps = Split-Path -Path (Split-Path -Path $GameRoot -Parent) -Parent
    $manifest = Get-SteamManifest (Join-Path $steamApps ('appmanifest_' + $script:TargetAppId + '.acf'))
    if ($null -eq $manifest -or $manifest.InstallFolder -ne (Split-Path -Path $GameRoot -Leaf)) {
        throw 'A matching Steam installation record was not found. Choose the folder opened by Steam for the full game.'
    }
    if ($manifest.BuildId -ne $script:TargetBuildId) {
        throw ('This test package is for Steam build ' + $script:TargetBuildId + '. Your build is ' + $manifest.BuildId + '. Send a new reference collection before installing this version.')
    }
    $files = @(
        @('GameAssembly.dll', $script:ExpectedGameHash),
        @('PresidentSim_Data/il2cpp_data/Metadata/global-metadata.dat', $script:ExpectedMetadataHash)
    )
    foreach ($row in $files) {
        $path = Join-Path $GameRoot $row[0]
        if (!(Test-UnlinkedPath $path) -or !(Test-Path -LiteralPath $path -PathType Leaf)) { throw ('A required game file is unavailable: ' + $row[0]) }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $row[1]) {
            throw ('The installed game differs from the supplied references (' + $row[0] + '). Send a new reference collection before installing this version.')
        }
    }
}

function Assert-RelativePayloadPath {
    param([string]$Path)
    if (!$Path -or $Path.Contains('\') -or $Path.StartsWith('/') -or $Path -match '[<>:"|?*\x00-\x1F]') { throw 'The package contains an invalid file path.' }
    foreach ($part in $Path.Split('/')) {
        if (!$part -or $part -eq '.' -or $part -eq '..' -or $part.EndsWith(' ') -or $part.EndsWith('.') -or
            $part -match '^(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$') { throw 'The package contains an unsafe file path.' }
    }
    if ($Path -notmatch '^(?:BepInEx/|dotnet/)' -and $Path -notin @('winhttp.dll','doorstop_config.ini','.doorstop_version')) {
        throw ('The package contains a file outside the allowed mod locations: ' + $Path)
    }
}

function Get-PayloadPlan {
    param([string]$PackageRoot, [string]$GameRoot)
    $manifestPath = Join-Path $PackageRoot 'PayloadManifest.json'
    if (!(Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'PayloadManifest.json is missing. Extract the complete mod package first.' }
    $manifest = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    if ($manifest.Format -ne 1 -or $manifest.Product -ne $script:ProductId -or
        $manifest.TargetAppId -ne $script:TargetAppId -or $manifest.TargetBuildId -ne $script:TargetBuildId) { throw 'This is not the expected editor package.' }
    $files = @($manifest.Files)
    if ($files.Count -lt 3 -or $files.Count -gt 1500) { throw 'The package file list is incomplete or invalid.' }
    $seen = @{}; $bytes = [long]0
    $plan = New-Object 'System.Collections.Generic.List[object]'
    foreach ($file in $files) {
        $relative = [string]$file.Path
        Assert-RelativePayloadPath $relative
        if ($seen.ContainsKey($relative)) { throw 'The package contains duplicate file paths.' }
        $seen[$relative] = $true
        if ([string]$file.SHA256 -notmatch '^[A-Fa-f0-9]{64}$' -or [long]$file.Bytes -lt 0) { throw 'The package contains invalid file checksums.' }
        $bytes += [long]$file.Bytes
        if ($bytes -gt 512MB) { throw 'The package is larger than the installer supports.' }
        $source = Join-Path (Join-Path $PackageRoot 'Payload') $relative
        $destination = Join-Path $GameRoot $relative
        if (!(Test-Path -LiteralPath $source -PathType Leaf) -or (Get-Item -LiteralPath $source -Force).Length -ne [long]$file.Bytes) { throw ('A package file is missing or incomplete: ' + $relative) }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $file.SHA256) { throw ('A package file failed its integrity check: ' + $relative) }
        if (Test-Path -LiteralPath $destination) { throw ('An existing file would be overwritten: ' + $relative + '. Nothing has been installed.') }
        $plan.Add([pscustomobject]@{ Path = $relative; Source = $source; Destination = $destination; Bytes = [long]$file.Bytes; SHA256 = [string]$file.SHA256 })
    }
    foreach ($required in @('winhttp.dll','doorstop_config.ini','BepInEx/plugins/PresidentValuesEditor/PresidentValuesEditor.dll')) {
        if (!$seen.ContainsKey($required)) { throw ('The package is missing ' + $required) }
    }
    return [pscustomobject]@{ Version = [string]$manifest.ModVersion; Files = @($plan.ToArray()) }
}

function New-LocalSaveBackup {
    param([string]$GameRoot, [string]$PackageRoot)
    $localData = [Environment]::GetFolderPath('LocalApplicationData')
    if (!$localData) { Write-Host 'Save folder could not be located. Use a new test save.' -ForegroundColor Yellow; return $null }
    $appData = Split-Path -Path $localData -Parent
    $source = Join-Path $appData 'LocalLow/Studio14b/PresidentSim'
    if (!(Test-Path -LiteralPath $source -PathType Container)) {
        Write-Host 'No save folder was found at the expected location. Use a new test save.' -ForegroundColor Yellow
        return $null
    }
    if (!(Test-UnlinkedPath $source)) { throw 'The save folder could not be backed up safely. No mod files have been installed.' }
    $sources = New-Object 'System.Collections.Generic.List[object]'
    $pending = New-Object 'System.Collections.Generic.Stack[string]'
    $pending.Push($source)
    $total = [long]0
    while ($pending.Count -gt 0) {
        foreach ($entry in Get-ChildItem -LiteralPath $pending.Pop() -Force) {
            if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'The save folder contains a linked item. No mod files have been installed.' }
            if ($entry.PSIsContainer) { $pending.Push($entry.FullName) }
            else {
                $total += [long]$entry.Length
                if ($sources.Count -ge 2000 -or $total -gt 256MB) { throw 'The save folder is unusually large. No mod files have been installed; ask for a tailored backup step.' }
                $relative = $entry.FullName.Substring($source.Length).TrimStart([char[]]'/\')
                $sources.Add([pscustomobject]@{ Source = $entry.FullName; Relative = $relative; Bytes = [long]$entry.Length })
            }
        }
    }
    $backupRoot = $null
    $name = 'PresidentSimulator_SaveBackup_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N').Substring(0,8)
    $gamePrefix = $GameRoot.TrimEnd([char[]]'/\') + [IO.Path]::DirectorySeparatorChar
    foreach ($candidate in @($localData, $PackageRoot, [IO.Path]::GetTempPath())) {
        try {
            if (!$candidate -or !(Test-UnlinkedPath $candidate)) { continue }
            $candidate = Get-FolderPath $candidate
            if ($candidate -eq $GameRoot -or $candidate.StartsWith($gamePrefix,[StringComparison]::OrdinalIgnoreCase)) { continue }
            $chosen = Join-Path $candidate $name
            if (Test-Path -LiteralPath $chosen) { continue }
            [void][IO.Directory]::CreateDirectory($chosen)
            $backupRoot = $chosen; break
        } catch { }
    }
    if (!$backupRoot) { throw 'No writable location was found for the save backup. No mod files have been installed.' }
    foreach ($file in $sources) {
        $destination = Join-Path $backupRoot $file.Relative
        [void][IO.Directory]::CreateDirectory((Split-Path -Path $destination -Parent))
        [IO.File]::Copy($file.Source,$destination,$false)
        if ((Get-FileHash -LiteralPath $file.Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash) {
            throw 'Save backup verification failed. No mod files have been installed.'
        }
    }
    Write-Host ('Local save backup: ' + $backupRoot) -ForegroundColor Green
    return $backupRoot
}

function Invoke-PayloadInstall {
    param([string]$GameRoot, [object]$Plan, [string]$BackupPath)
    $createdFiles = New-Object 'System.Collections.Generic.List[string]'
    $createdDirectories = New-Object 'System.Collections.Generic.List[string]'
    $lockPath = Join-Path $GameRoot 'PresidentValuesEditor.installing.lock'
    $lock = $null; $lockOwned = $false
    try {
        $lock = [IO.File]::Open($lockPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
        $lockOwned = $true
        $orderedFiles = @($Plan.Files | Where-Object { $_.Path -ne 'winhttp.dll' }) + @($Plan.Files | Where-Object { $_.Path -eq 'winhttp.dll' })
        foreach ($file in $orderedFiles) {
            if ($file.Path -eq 'winhttp.dll') {
                Assert-GameClosed
                Assert-CompatibleGame $GameRoot
            }
            $parts = $file.Path.Split('/')
            $parent = $GameRoot
            for ($i=0; $i -lt ($parts.Length-1); $i++) {
                $parent = Join-Path $parent $parts[$i]
                if (!(Test-Path -LiteralPath $parent)) {
                    [void][IO.Directory]::CreateDirectory($parent)
                    $createdDirectories.Add($parent)
                }
                if (!(Test-UnlinkedPath $parent)) { throw 'A destination folder changed during installation.' }
            }
            $sourceStream = $null; $destinationStream = $null
            try {
                $sourceStream = [IO.File]::Open($file.Source,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
                $destinationStream = [IO.File]::Open($file.Destination,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
                $createdFiles.Add($file.Destination)
                $sourceStream.CopyTo($destinationStream)
            } finally {
                if ($null -ne $destinationStream) { $destinationStream.Dispose() }
                if ($null -ne $sourceStream) { $sourceStream.Dispose() }
            }
            if ((Get-FileHash -LiteralPath $file.Destination -Algorithm SHA256).Hash -ne $file.SHA256) { throw ('Copied file failed verification: ' + $file.Path) }
        }
        $record = [ordered]@{
            Format = 1; Product = $script:ProductId; ModVersion = $Plan.Version
            TargetAppId = $script:TargetAppId; TargetBuildId = $script:TargetBuildId
            InstalledUtc = [DateTime]::UtcNow.ToString('o'); SaveBackup = $BackupPath
            Files = @($Plan.Files | ForEach-Object { [pscustomobject]@{ Path=$_.Path; Bytes=$_.Bytes; SHA256=$_.SHA256 } })
        }
        $recordPath = Join-Path $GameRoot $script:InstallRecordName
        $stream = $null; $writer = $null
        try {
            $stream = [IO.File]::Open($recordPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            $createdFiles.Add($recordPath)
            $writer = New-Object IO.StreamWriter($stream, (New-Object Text.UTF8Encoding($false)))
            $writer.Write(($record | ConvertTo-Json -Depth 6))
        } finally {
            if ($null -ne $writer) { $writer.Dispose() }
            elseif ($null -ne $stream) { $stream.Dispose() }
        }
    } catch {
        $failure = $_
        for ($i=$createdFiles.Count-1; $i -ge 0; $i--) {
            try { [IO.File]::Delete($createdFiles[$i]) } catch { Write-Host ('Could not remove a new installer file: ' + $createdFiles[$i]) -ForegroundColor Yellow }
        }
        for ($i=$createdDirectories.Count-1; $i -ge 0; $i--) {
            try { [IO.Directory]::Delete($createdDirectories[$i],$false) } catch { }
        }
        throw $failure
    } finally {
        if ($null -ne $lock) { $lock.Dispose() }
        if ($lockOwned) { try { [IO.File]::Delete($lockPath) } catch { } }
    }
}

function Set-EditorEnabled {
    param([string]$GameRoot,[bool]$Enabled)
    $recordPath = Join-Path $GameRoot $script:InstallRecordName
    if (!(Test-UnlinkedPath $recordPath)) { throw 'The editor installation record was not found. No files were changed.' }
    $record = [IO.File]::ReadAllText($recordPath) | ConvertFrom-Json
    if ($record.Format -ne 1 -or $record.Product -ne $script:ProductId -or $record.TargetAppId -ne $script:TargetAppId) { throw 'The editor installation record is not recognised.' }
    $proxy = @($record.Files | Where-Object { $_.Path -eq 'winhttp.dll' })
    if ($proxy.Count -ne 1 -or [string]$proxy[0].SHA256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'The editor installation record is incomplete.' }
    $active = Join-Path $GameRoot 'winhttp.dll'
    $disabled = Join-Path $GameRoot $script:DisabledProxyName
    $source = if ($Enabled) { $disabled } else { $active }
    $destination = if ($Enabled) { $active } else { $disabled }
    if (!(Test-Path -LiteralPath $source -PathType Leaf)) {
        if ((Test-UnlinkedPath $destination) -and (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -eq $proxy[0].SHA256) {
            Write-Host $(if ($Enabled) { 'The editor is already enabled.' } else { 'The editor is already disabled.' })
            return
        }
        throw 'The expected editor loader file was not found. No files were changed.'
    }
    if (!(Test-UnlinkedPath $source) -or (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $proxy[0].SHA256) { throw 'The loader file differs from the one installed by this package. No files were changed.' }
    if (Test-Path -LiteralPath $destination) { throw 'A file already occupies the destination. No files were changed.' }
    if ($Enabled) { Assert-CompatibleGame $GameRoot }
    Assert-GameClosed
    [IO.File]::Move($source,$destination)
    Write-Host $(if ($Enabled) { 'Editor enabled. Start the game normally through Steam.' } else { 'Editor disabled. Start the game normally through Steam.' }) -ForegroundColor Green
}
