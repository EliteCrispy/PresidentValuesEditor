@echo off
setlocal
title President Simulator - Disable Values Editor
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Manage_Editor.ps1" -Action Disable %*
set "president_editor_result=%errorlevel%"
echo.
pause
exit /b %president_editor_result%
