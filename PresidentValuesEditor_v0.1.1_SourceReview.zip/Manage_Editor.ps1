#requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Install','Disable','Enable')][string]$Action = 'Install',
    [string]$GamePath
)
$ErrorActionPreference = 'Stop'
try {
    . (Join-Path $PSScriptRoot 'Installer.Common.ps1')
    Write-Host ''
    Write-Host ('President Simulator Values Editor - ' + $Action) -ForegroundColor Cyan
    Assert-GameClosed
    $game = Get-SelectedGamePath $GamePath
    Write-Host ('Game folder: ' + $game)
    if ($Action -ne 'Install') {
        Set-EditorEnabled -GameRoot $game -Enabled ($Action -eq 'Enable')
        exit 0
    }
    Write-Host 'Checking the game version and package...'
    Assert-CompatibleGame $game
    foreach ($conflict in @('BepInEx','dotnet','MelonLoader','winhttp.dll','version.dll','doorstop_config.ini','.doorstop_version',
                            $script:InstallRecordName,$script:DisabledProxyName,'PresidentValuesEditor.installing.lock')) {
        if (Test-Path -LiteralPath (Join-Path $game $conflict)) { throw ('An existing loader or editor file was found: ' + $conflict + '. This first-install helper will not overwrite it. Send the message for an appropriate update step.') }
    }
    $plan = Get-PayloadPlan -PackageRoot $PSScriptRoot -GameRoot $game
    $backup = New-LocalSaveBackup -GameRoot $game -PackageRoot $PSScriptRoot
    Assert-GameClosed
    Write-Host 'Installing the editor...'
    Invoke-PayloadInstall -GameRoot $game -Plan $plan -BackupPath $backup
    Write-Host ''
    Write-Host 'Installation complete. Start President Simulator through Steam.' -ForegroundColor Green
    Write-Host 'Use the editor hotkey shown in README.txt. First startup may take longer while the loader prepares game references.'
    Write-Host 'Use a separate test save for the first edits.'
    Write-Host 'To turn the editor off, close the game and run Disable_Editor.cmd.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('Stopped: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Copy this message or send a screenshot of this window if you need help.'
    exit 1
}
