PRESIDENT VALUES EDITOR v0.1.1
For President Simulator by Studio 14b

REQUIREMENTS AND STATUS
-----------------------
Supported game: Steam app 3705900, build 26325310
Supported platform: Windows x64 | Unity 6000.3.9f1
Installation: manual download and the included Install_Editor.cmd
Vortex installation is not supported by this package.

This is an unofficial community mod. The menu and editing have been tested
by one player on the exact game build above. Money, popularity and all six
national stats survived a day change and a normal save/reload in that test.
PAINT HAS A KNOWN LIMITATION: an edited repair balance survived a day change
but returned to 0 after loading the save. Treat paint edits as temporary and
reapply them after loading if needed. Results on other PCs are not guaranteed.

WHAT YOU CAN EDIT
-----------------
Press F6 after loading a game. Each row shows the current value, a new-value
box and its own Apply button. Apply sets that value's total; it does not add
the typed number. Opening the menu does not apply changes. F6 or Esc closes it.

Value             Accepted input
Money             0 to 1,000,000,000; whole numbers
Popularity        0 to 100 percent; decimals allowed
Paint / repairs   0 to 1,000,000 available repair tokens; whole numbers
Justice           0 to 100; whole numbers
Culture           0 to 100; whole numbers
Economy           0 to 100; whole numbers
Health            0 to 100; whole numbers
Military          0 to 100; whole numbers
Environment       0 to 100; whole numbers

Use digits without commas, currency symbols or a percent sign. Use a decimal
point for popularity: 0.66 means 0.66%. The 100% limit applies to what the
editor accepts; gameplay can raise the current value above 100%. The editor
can display such a value without forcing it back down.

Locked national stats remain read-only until the game unlocks them normally.
Each unlocked stat shows its current green range. Higher numbers are not
automatically better; choose values using the game's displayed safe range.
Reload input values copies current values into the boxes without applying them.

The game clock pauses while the editor is open. Edits are one-time changes;
normal gameplay can change the values again when you close it. Increasing
popularity can raise the game's highest-popularity record and permanently
unlock normal progression rewards, including paint. Lowering popularity later
does not undo those unlocks. The popularity machine's history graph takes its
next timed sample after play resumes.

FRESH INSTALL
-------------
This complete package includes its required loader. Install it only into an
unmodded supported game. It refuses an existing BepInEx/MelonLoader installation
or conflicting loader files. For an existing v0.1.0 editor installation, use
the separate v0.1.1 hotfix package; do not install this package over it.

1. Close President Simulator and let any Steam update finish.
2. Extract the complete ZIP into a fresh folder outside the game installation.
   Keep the helpers, Payload folder and PayloadManifest.json together.
3. Double-click Install_Editor.cmd once. No Python or separate .NET install
   is needed. The helper normally finds the game through Steam.
4. If asked for a folder, use Steam > right-click President Simulator >
   Manage > Browse local files. Paste that folder address into the helper.
5. After installation succeeds, start the game normally through Steam.
   Stay online for the first startup: the loader may download matching Unity
   reference libraries and generate local references. This can take longer.
6. Load a separate test save, press F6, and apply one small change. Close the
   editor with F6 or Esc to resume playing.

The helper checks the Steam build, game-file hashes and every installed
payload file. If it stops, read its message and report the problem. Do not
force installation into an unknown game build or overwrite another loader.
The installer itself does not download files and does not need administrator
access when your Steam game folder is writable by your Windows account.

SAVE BACKUP AND YOUR FIRST CHECK
-------------------------------
Before installation, the helper backs up the expected local save folder,
AppData\LocalLow\Studio14b\PresidentSim, if it exists. It normally writes to
%LOCALAPPDATA%\PresidentSimulator_SaveBackup_... and prints the actual path.
If needed, it tries the extracted package folder or Windows temporary folder.
The backup path is also in PresidentValuesEditor.install.json in the game
folder. Backups stay on your PC. If no save folder is found, the helper says so.

Keep that backup. In a separate test save, check that the displayed values
match the game, make a small money edit and purchase, try an available repair,
then save normally and reload. Check the eight persistent values again; the
paint reload limitation above is already known. This mod does not autosave
edits or freeze values, and ordinary gameplay can change them between checks.

DISABLE, RE-ENABLE AND GAME UPDATES
---------------------------------
Close the game and run Disable_Editor.cmd to turn off this package's loader.
Enable_Editor.cmd reverses the action after checking game compatibility.
These helpers verify the owned loader before renaming it.

Disabling does not undo edits already saved, reverse progression or restore
the save backup. Keep the extracted package for these helpers.

After a game update, run Disable_Editor.cmd before launching the updated game
until compatibility has been checked. This release supports only the exact
build listed above. The plugin's hash guard runs after the loader has started;
it cannot make the loader compatible with a future Unity/game update.

TROUBLESHOOTING
---------------
If installation stops, report its full message or a screenshot. If the game
will not start, close it, run Disable_Editor.cmd and try the normal game.
For a loading/editor problem, include your game build, the action that failed
and the relevant error from <game folder>\BepInEx\LogOutput.log, if created.
Review a log before sharing it; it can contain local paths. Saved games and
automatic backups are not needed for initial troubleshooting.

The default hotkey is F6. After first startup, it can be changed in:
BepInEx\config\elitecrispy.presidentsimulator.valueseditor.cfg
ToggleKey accepts F1-F12, Insert or Home. Avoid F8, which the game uses for bug
reporting. Close the game before editing that configuration file.

SOURCE, CREDITS AND CHANGE IN v0.1.1
----------------------------------
Version 0.1.1 fixes the native policy-list enumeration error that prevented
the menu opening in v0.1.0. The numerical rules and loader are unchanged.

Included: BepInEx 6 build 791 and a custom Il2CppInterop build containing the
community Unity 6.3 compatibility change identified in ThirdParty. This is
not an official Studio 14b release or an upstream compatibility guarantee.

AI disclosure: the editor code/UI and public listing were drafted with
ChatGPT. The player performed the reported in-game testing. Bundled third-
party dependencies are the work of their respective upstream authors; their
credits and licenses remain separate from this editor.

Source/LICENSE.txt covers the editor, helpers and original documentation.
ThirdParty contains the bundled components' notices, licenses, provenance
and expanded corresponding source. Source/Editor contains the v0.1.1 editor
source and build instructions. No game binaries, generated game wrappers or
saved games are included. See VALIDATION.txt for the precise test scope.
