using PresidentValuesEditor;

var checks = new List<string>();
void Check(bool okay, string scenario)
{
    if (!okay) throw new InvalidOperationException("FAILED: " + scenario);
    checks.Add(scenario);
}

Check(EditorRules.TryPopularity("0.66", out var popular) && Math.Abs(popular - 0.0066f) < 0.0000001f,
    "Screenshot popularity 0.66% becomes the game's 0.0066 value");
Check(Math.Abs(EditorRules.DisplayPopularity(popular) - 0.66d) < 0.00001d,
    "Game popularity reads back in display percent");
Check(EditorRules.TryPopularity("100", out var maximum) && maximum == 1f,
    "100% corresponds to internal one");
foreach (string invalid in new[] { "", " ", "NaN", "Infinity", "1e999", "-1", "100.01", "0,66", "1.2.3" })
    Check(!EditorRules.TryPopularity(invalid, out _), "Reject invalid popularity: '" + invalid + "'");
Check(EditorRules.TryWholeNumber("606", EditorRules.MaximumMoney, out int money) && money == 606,
    "Screenshot cash remains integer dollars");
Check(EditorRules.TryWholeNumber("0", EditorRules.MaximumPaint, out int zero) && zero == 0,
    "Zero paint is a valid requested balance");
foreach (string invalid in new[] { "", "-1", "1.5", "1,000", "2147483648", "1000000001" })
    Check(!EditorRules.TryWholeNumber(invalid, EditorRules.MaximumMoney, out _), "Reject invalid cash: '" + invalid + "'");
Check(EditorRules.TryWholeNumber("87", 100, out int policy) && policy == 87,
    "Policy scores remain unscaled 0-100 integers");
Check(!EditorRules.TryWholeNumber("101", 100, out _), "Reject a policy outside its native range");
Check(EditorRules.TryPaintAdjustment(25, 7, 0, out int add) && add == 18,
    "Set available paint via delta, accounting for already-earned tokens");
Check(EditorRules.TryPaintAdjustment(0, 25, 18, out int subtract) && subtract == -25,
    "Decreasing available paint works without altering spending history");
Check(EditorRules.TryPaintAdjustment(25, 12, 0, out int afterRewards) && afterRewards == 13,
    "Freshly earned popularity rewards are included in the latest paint delta");
Check(!EditorRules.TryPaintAdjustment(1, int.MinValue, 0, out _),
    "Reject delta overflow without wrapping the native int");
Check(!EditorRules.TryPaintAdjustment(100, 0, int.MaxValue, out _),
    "Reject overflow in AdditionalTokens even when delta itself fits");
Check(!EditorRules.TryPaintAdjustment(EditorRules.MaximumPaint + 1, 0, 0, out _),
    "Apply the published first-test paint limit");
Console.WriteLine($"PASS: {checks.Count} numeric and state-transition checks.");
foreach (var check in checks) Console.WriteLine("PASS " + check);
