using System.Security.Cryptography;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;

namespace PresidentValuesEditor;

[BepInPlugin(Id, Name, Version)]
[BepInProcess("PresidentSim.exe")]
public sealed class Plugin : BasePlugin
{
    public const string Id = "elitecrispy.presidentsimulator.valueseditor";
    public const string Name = "President Values Editor";
    public const string Version = "0.1.1";
    internal const string ExpectedGameHash = "0A181872756862446B3E9D8A36BFFB6A8873849FF3AC795F54AF2C31CC2C30AE";
    internal const string ExpectedMetadataHash = "F751CC755DEF26E6CA81E84235091A04D5C019329FABBADEA274965E79D1377E";

    internal static ManualLogSource LogSink { get; private set; } = null!;
    internal static int ToggleVirtualKey { get; private set; } = 0x75; // F6
    internal static string ToggleKeyLabel { get; private set; } = "F6";
    private EditorOverlay? _overlay;

    public override void Load()
    {
        LogSink = Log;
        try
        {
            string root = Paths.GameRootPath;
            if (!MatchesHash(Path.Combine(root, "GameAssembly.dll"), ExpectedGameHash)
                || !MatchesHash(Path.Combine(root, "PresidentSim_Data", "il2cpp_data", "Metadata", "global-metadata.dat"), ExpectedMetadataHash))
            {
                Log.LogError("Editor disabled: this test release requires the verified President Simulator build 26325310. Collect new references after a game update.");
                return;
            }
            ConfigEntry<string> key = Config.Bind("General", "ToggleKey", "F6", "Editor toggle: F1 through F12, Insert or Home. The default is F6; the game uses F8 for bug reports.");
            string name = key.Value.Trim().ToUpperInvariant();
            if (name.Length is 2 or 3 && name[0] == 'F' && int.TryParse(name.AsSpan(1), out int number) && number is >= 1 and <= 12)
            {
                ToggleVirtualKey = 0x6F + number;
                ToggleKeyLabel = "F" + number;
            }
            else if (name is "INSERT" or "HOME")
            {
                ToggleVirtualKey = name == "INSERT" ? 0x2D : 0x24;
                ToggleKeyLabel = name == "INSERT" ? "Insert" : "Home";
            }
            else Log.LogWarning("Unknown ToggleKey; using F6.");

            _overlay = AddComponent<EditorOverlay>();
            Log.LogInfo($"President Values Editor {Version} ready. Load a game and press {ToggleKeyLabel}. No values change until you press Apply.");
        }
        catch (Exception e)
        {
            Log.LogError("Editor could not initialize: " + e);
        }
    }

    public override bool Unload()
    {
        if (_overlay != null) UnityEngine.Object.Destroy(_overlay);
        return true;
    }

    private static bool MatchesHash(string path, string expected)
    {
        using FileStream stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        using SHA256 hash = SHA256.Create();
        return Convert.ToHexString(hash.ComputeHash(stream)).Equals(expected, StringComparison.OrdinalIgnoreCase);
    }
}
