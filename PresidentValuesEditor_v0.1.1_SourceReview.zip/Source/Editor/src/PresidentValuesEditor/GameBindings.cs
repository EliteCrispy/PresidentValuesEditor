using System.Globalization;
using Core;
using Features.Day;
using Features.Policies;
using Features.Renovation;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes;
using PresidentSim.Lifetimes;
using Sources.WorldObjects;
using UnityEngine;
using VContainer;
using Policy = Features.Policies.Types.Policies;
using UObject = UnityEngine.Object;

namespace PresidentValuesEditor;

internal sealed class GameBindings
{
    internal MainSceneLifetime Scope { get; }
    internal CurrencyService Currency { get; }
    internal CurrencyState CurrencyState { get; }
    internal PoliciesService Policies { get; }
    internal PolicyState PolicyState { get; }
    internal RenovationService Renovation { get; }
    internal DayService Day { get; }
    internal FlowState Flow { get; }

    private GameBindings(MainSceneLifetime scope)
    {
        Scope = scope;
        IObjectResolver container = scope.Container;
        Currency = Resolve<CurrencyService>(container);
        CurrencyState = Currency.CurrencyState;
        Policies = Resolve<PoliciesService>(container);
        PolicyState = Policies.PolicyState;
        Renovation = Resolve<RenovationService>(container);
        Day = Resolve<DayService>(container);
        Flow = Resolve<FlowState>(container);
        if (CurrencyState == null || PolicyState == null || Renovation.RenovationState == null)
            throw new InvalidOperationException("Game services are still initializing.");
    }

    internal bool Ready => Scope != null && Scope.gameObject.activeInHierarchy && Flow.Running && !Flow.LoadFailed;

    internal static bool TryCreate(out GameBindings? bindings)
    {
        bindings = null;
        var found = UObject.FindObjectOfType(Il2CppType.Of<MainSceneLifetime>());
        if (found == null) return false;
        var scope = found.Cast<MainSceneLifetime>();
        if (scope.Container == null) return false;
        var result = new GameBindings(scope);
        if (!result.Ready) return false;
        bindings = result;
        return true;
    }

    private static T Resolve<T>(IObjectResolver container) where T : Il2CppObjectBase
    {
        var value = container.Resolve(Il2CppType.Of<T>(), null);
        if (value == null) throw new InvalidOperationException("Missing game service: " + typeof(T).Name);
        return value.Cast<T>();
    }

    internal HashSet<Policy> UnlockedPolicies()
    {
        var result = new HashSet<Policy>();
        var collection = Policies.GetUnlockedPolicies();
        if (collection == null) throw new InvalidOperationException("The game's unlocked-stat list is not available yet.");

        // In the supported game build this getter returns a newly allocated
        // List<Policy>. Walk that snapshot by index: invoking the boxed native
        // List enumerator through IEnumerator throws on the user's IL2CPP
        // runtime, even though this editor never modifies the returned list.
        var snapshot = collection.Cast<Il2CppSystem.Collections.Generic.List<Policy>>();
        int count = snapshot.Count;
        for (int i = 0; i < count; i++) result.Add(snapshot[i]);
        return result;
    }

    internal void SetMoney(int value)
    {
        EnsureReady();
        CurrencyState.SetCash(value, true);
        if (Currency.GetCash() != value) throw new InvalidOperationException("The game did not keep the requested money value.");
    }

    internal void SetPopularity(float storedValue)
    {
        EnsureReady();
        CurrencyState.SetPopularity(storedValue);
        if (Math.Abs(Currency.GetPopularity() - storedValue) > 0.000001f)
            throw new InvalidOperationException("The game did not keep the requested popularity value.");
        // Native change events update the HUD and progression. The machine's
        // history graph takes its next genuine sample after the clock resumes.
    }

    internal void SetPaint(int desired)
    {
        EnsureReady();
        int available = Renovation.GetAvailableTokens();
        int additional = Renovation.RenovationState.DataInstance.AdditionalTokens;
        if (!EditorRules.TryPaintAdjustment(desired, available, additional, out int delta))
            throw new InvalidOperationException("That paint adjustment exceeds the game's integer range.");
        if (delta != 0) Renovation.AddTokens(delta);
        int actual = Renovation.GetAvailableTokens();
        if (actual != desired) throw new InvalidOperationException("The game returned a different paint balance; refresh and try again.");

        foreach (var obj in UObject.FindObjectsOfType(Il2CppType.Of<RenovationUi>()))
        {
            if (obj == null) continue;
            try
            {
                var ui = obj.Cast<RenovationUi>();
                if (ui.RenovationService != null) ui.UpdateTokenDisplay();
            }
            catch (Exception e) { Plugin.LogSink.LogWarning("Paint changed, but a HUD refresh was unavailable: " + e.Message); }
        }
    }

    internal void SetPolicy(Policy policy, int value)
    {
        EnsureReady();
        if (!UnlockedPolicies().Contains(policy)) throw new InvalidOperationException("This stat is still locked in the game.");
        PolicyState.SetProgress(policy, value);
        if (Policies.GetPolicyValue(policy) != value)
            throw new InvalidOperationException("The game did not keep the requested stat value.");
    }

    private void EnsureReady()
    {
        if (!Ready) throw new InvalidOperationException("Wait until your game has finished loading.");
    }
}
