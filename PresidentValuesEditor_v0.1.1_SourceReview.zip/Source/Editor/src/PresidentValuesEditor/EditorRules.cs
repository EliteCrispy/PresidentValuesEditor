using System.Globalization;

namespace PresidentValuesEditor;

/// <summary>Pure validation/conversion rules, independent of Unity and the loader.</summary>
internal static class EditorRules
{
    // Intentional limits for this first test release; not claims about game caps.
    internal const int MaximumMoney = 1_000_000_000;
    internal const int MaximumPaint = 1_000_000;

    internal static bool TryWholeNumber(string text, int maximum, out int value)
    {
        value = 0;
        text = text.Trim();
        if (text.Length == 0 || text.Any(c => c is < '0' or > '9')) return false;
        return int.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out value)
               && value >= 0 && value <= maximum;
    }

    internal static bool TryPopularity(string text, out float internalValue)
    {
        internalValue = 0;
        text = text.Trim();
        if (text.Length == 0 || text.Any(c => (c is < '0' or > '9') && c != '.')) return false;
        if (!double.TryParse(text, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double percent)
            || !double.IsFinite(percent) || percent < 0 || percent > 100) return false;
        internalValue = (float)(percent / 100d);
        return true;
    }

    internal static double DisplayPopularity(float storedValue) => (double)storedValue * 100d;

    internal static bool TryPaintAdjustment(int desired, int available, int additional, out int delta)
    {
        delta = 0;
        if (desired < 0 || desired > MaximumPaint) return false;
        long difference = (long)desired - available;
        long newAdditional = (long)additional + difference;
        if (difference is < int.MinValue or > int.MaxValue || newAdditional is < int.MinValue or > int.MaxValue)
            return false;
        delta = (int)difference;
        return true;
    }
}
