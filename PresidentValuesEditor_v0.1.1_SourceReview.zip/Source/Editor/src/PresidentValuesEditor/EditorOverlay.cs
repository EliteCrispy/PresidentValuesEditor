using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using Il2CppInterop.Runtime.Attributes;
using UnityEngine;
using Policy = Features.Policies.Types.Policies;

namespace PresidentValuesEditor;

public sealed class EditorOverlay : MonoBehaviour
{
    private static readonly CultureInfo Culture = CultureInfo.InvariantCulture;
    private static readonly Policy[] PolicyOrder = { Policy.Justice, Policy.Culture, Policy.Economy, Policy.Health, Policy.Military, Policy.Environment };
    private readonly string[] _draft = new string[9];
    private readonly string[] _current = new string[9];
    private readonly string[] _notes = new string[9];
    private readonly bool[] _editable = new bool[9];
    private GameBindings? _game;
    private InputGuard? _guard;
    private bool _open;
    private bool _toggleHeld;
    private bool _escapeHeld;
    private float _nextRefresh;
    private float _noticeUntil;
    private string _notice = "";
    private string _result = "Choose a value, type a number, then press its Apply button.";
    private bool _resultError;
    private GUIStyle? _titleStyle;
    private GUIStyle? _smallStyle;
    private GUIStyle? _bodyStyle;
    private GUIStyle? _valueStyle;
    private GUIStyle? _inputStyle;
    private GUIStyle? _buttonStyle;

    public EditorOverlay(IntPtr pointer) : base(pointer) { }

    public void Update()
    {
        try
        {
            bool focused = IsGameFocused();
            bool toggle = focused && IsKeyDown(Plugin.ToggleVirtualKey);
            bool escape = focused && IsKeyDown(0x1B);
            if (toggle && !_toggleHeld)
            {
                if (_open) CloseEditor(); else OpenEditor();
            }
            else if (_open && escape && !_escapeHeld) CloseEditor();
            _toggleHeld = toggle;
            _escapeHeld = escape;

            if (_open && (_game == null || !_game.Ready))
            {
                CloseEditor();
                _game = null;
                ShowNotice("Editor closed while the game changed scenes.");
            }
            if (_open && Time.unscaledTime >= _nextRefresh)
            {
                ReadValues(false);
                _nextRefresh = Time.unscaledTime + 0.3f;
            }
        }
        catch (Exception e)
        {
            Plugin.LogSink.LogError("Editor update failed: " + e);
            CloseEditor();
            _game = null;
            ShowNotice("Editor stopped safely. See BepInEx/LogOutput.log for details.");
        }
    }

    public void LateUpdate()
    {
        if (_open) _guard?.KeepCursorFree();
    }

    public void OnDisable() => CloseEditor();
    public void OnDestroy() => CloseEditor();

    [HideFromIl2Cpp]
    private void OpenEditor()
    {
        if (!GameBindings.TryCreate(out _game))
        {
            ShowNotice("Load your game first, then press " + Plugin.ToggleKeyLabel + ".");
            return;
        }
        ReadValues(true);
        _guard = new InputGuard(_game!.Day);
        try { _guard.Acquire(); }
        catch { _guard.Dispose(); _guard = null; throw; }
        _open = true;
        _result = "Game clock paused. Edit one value at a time; close to continue playing.";
        _resultError = false;
        _nextRefresh = 0;
    }

    [HideFromIl2Cpp]
    private void CloseEditor()
    {
        _open = false;
        _guard?.Dispose();
        _guard = null;
    }

    [HideFromIl2Cpp]
    private void ShowNotice(string text)
    {
        _notice = text;
        _noticeUntil = Time.unscaledTime + 6f;
    }

    [HideFromIl2Cpp]
    private void ReadValues(bool resetDrafts)
    {
        if (_game == null) return;
        bool[] previouslyEditable = (bool[])_editable.Clone();
        _current[0] = _game.Currency.GetCash().ToString(Culture);
        _current[1] = EditorRules.DisplayPopularity(_game.Currency.GetPopularity()).ToString("0.####", Culture);
        _current[2] = _game.Renovation.GetAvailableTokens().ToString(Culture);
        _notes[0] = "Whole number, 0 to 1,000,000,000";
        _notes[1] = "Percent, 0 to 100; use a decimal point";
        _notes[2] = "Available repair tokens, 0 to 1,000,000";
        _editable[0] = _editable[1] = _editable[2] = true;
        var unlocked = _game.UnlockedPolicies();
        for (int p = 0; p < PolicyOrder.Length; p++)
        {
            int row = p + 3;
            Policy policy = PolicyOrder[p];
            bool available = unlocked.Contains(policy);
            _editable[row] = available;
            if (available)
            {
                _current[row] = _game.Policies.GetPolicyValue(policy).ToString(Culture);
                Vector2 range = _game.Policies.GetSafeRange(policy);
                _notes[row] = "0-100 | current green range: " + range.x.ToString("0.#", Culture) + " to " + range.y.ToString("0.#", Culture);
            }
            else
            {
                _current[row] = "Locked";
                _notes[row] = "Available here when this stat unlocks in the game";
            }
        }
        for (int i = 0; i < _draft.Length; i++)
        {
            // Do not refill an intentionally cleared field while the user types.
            if (resetDrafts || (!previouslyEditable[i] && _editable[i]))
                _draft[i] = _editable[i] ? _current[i] : "";
        }
    }

    [HideFromIl2Cpp]
    private void ApplyRow(int row)
    {
        try
        {
            if (_game == null || !_game.Ready || !_editable[row]) throw new InvalidOperationException("This value is not available yet.");
            if (row == 1)
            {
                if (!EditorRules.TryPopularity(_draft[row], out float value)) throw new ArgumentException("Enter a popularity percentage from 0 to 100, for example 0.66.");
                _game.SetPopularity(value);
            }
            else
            {
                int max = row == 0 ? EditorRules.MaximumMoney : row == 2 ? EditorRules.MaximumPaint : 100;
                if (!EditorRules.TryWholeNumber(_draft[row], max, out int value))
                    throw new ArgumentException("Enter a whole number from 0 to " + max.ToString("N0", Culture) + ". Use digits without commas.");
                if (row == 0) _game.SetMoney(value);
                else if (row == 2) _game.SetPaint(value);
                else _game.SetPolicy(PolicyOrder[row - 3], value);
            }
            ReadValues(false);
            _draft[row] = _current[row];
            _result = RowName(row) + " set to " + _current[row] + (row == 1 ? "%" : "") + ".";
            if (row == 1) _result += " The machine's graph samples again after you resume.";
            _resultError = false;
            Plugin.LogSink.LogInfo(_result);
        }
        catch (Exception e)
        {
            _result = e.Message;
            _resultError = true;
            Plugin.LogSink.LogWarning("Apply " + RowName(row) + ": " + e);
        }
    }

    [HideFromIl2Cpp]
    private static string RowName(int row) => row switch
    {
        0 => "Money ($)",
        1 => "Popularity (%)",
        2 => "Paint / repairs",
        _ => PolicyOrder[row - 3].ToString()
    };

    public void OnGUI()
    {
        if (!_open)
        {
            if (Time.unscaledTime < _noticeUntil) GUI.Box(new Rect(20, 20, Math.Min(650, Screen.width - 40), 50), _notice);
            return;
        }
        Matrix4x4 oldMatrix = GUI.matrix;
        Color oldColor = GUI.color;
        Color oldBackground = GUI.backgroundColor;
        bool oldEnabled = GUI.enabled;
        int oldDepth = GUI.depth;
        try
        {
            EnsureStyles();
            const float width = 780;
            const float height = 748;
            float scale = Math.Min(1.15f, Math.Min(Screen.width / (width + 40), Screen.height / (height + 40)));
            scale = Math.Max(0.4f, scale);
            float x = (Screen.width / scale - width) * 0.5f;
            float y = (Screen.height / scale - height) * 0.5f;
            GUI.matrix = Matrix4x4.TRS(new Vector3(0, 0, 0), Quaternion.identity, new Vector3(scale, scale, 1));
            GUI.depth = -10000;
            GUI.backgroundColor = new Color(0.07f, 0.12f, 0.17f, 1);
            GUI.Box(new Rect(x, y, width, height), "");
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 24, y + 18, 540, 38), "President Values Editor", _titleStyle!);
            GUI.Label(new Rect(x + 24, y + 57, 620, 24), "Test v" + Plugin.Version + "  |  " + Plugin.ToggleKeyLabel + " or Esc closes the editor", _smallStyle!);
            if (GUI.Button(new Rect(x + 662, y + 22, 94, 34), "Close", _buttonStyle!)) { CloseEditor(); return; }

            GUI.Label(new Rect(x + 24, y + 96, 250, 24), "VALUE", _smallStyle!);
            GUI.Label(new Rect(x + 314, y + 96, 120, 24), "CURRENT", _smallStyle!);
            GUI.Label(new Rect(x + 450, y + 96, 170, 24), "NEW VALUE", _smallStyle!);
            for (int row = 0; row < 9; row++)
            {
                float ry = y + 124 + row * 53;
                GUI.enabled = true;
                GUI.Label(new Rect(x + 24, ry, 275, 26), RowName(row), _bodyStyle!);
                GUI.Label(new Rect(x + 24, ry + 25, 416, 22), _notes[row] ?? "", _smallStyle!);
                GUI.Label(new Rect(x + 314, ry, 126, 29), _current[row] ?? "", _valueStyle!);
                GUI.enabled = _editable[row];
                _draft[row] = GUI.TextField(new Rect(x + 450, ry + 1, 178, 32), _draft[row] ?? "", 24, _inputStyle!);
                if (GUI.Button(new Rect(x + 646, ry + 1, 110, 32), "Apply", _buttonStyle!)) ApplyRow(row);
            }
            GUI.enabled = true;
            GUI.color = _resultError ? new Color(1, 0.55f, 0.45f) : new Color(0.67f, 0.91f, 0.82f);
            GUI.Label(new Rect(x + 24, y + 612, 732, 49), _result, _bodyStyle!);
            GUI.color = Color.white;
            GUI.Label(new Rect(x + 24, y + 664, 718, 42), "Higher popularity can permanently unlock rewards. Lowering it does not undo unlocks.\nChanges follow normal gameplay and saving; values are not frozen.", _smallStyle!);
            if (GUI.Button(new Rect(x + 24, y + 712, 180, 26), "Reload input values", _buttonStyle!)) ReadValues(true);
            GUI.Label(new Rect(x + 260, y + 712, 496, 26), "The current green range is shown for each unlocked stat.", _smallStyle!);
        }
        catch (Exception e)
        {
            Plugin.LogSink.LogError("Editor drawing failed: " + e);
            CloseEditor();
            ShowNotice("Editor could not draw. See BepInEx/LogOutput.log.");
        }
        finally
        {
            GUI.matrix = oldMatrix;
            GUI.color = oldColor;
            GUI.backgroundColor = oldBackground;
            GUI.enabled = oldEnabled;
            GUI.depth = oldDepth;
        }
    }

    [HideFromIl2Cpp]
    private void EnsureStyles()
    {
        if (_titleStyle != null) return;
        _titleStyle = new GUIStyle(GUI.skin.label) { fontSize = 25, fontStyle = FontStyle.Bold };
        _bodyStyle = new GUIStyle(GUI.skin.label) { fontSize = 15, wordWrap = true };
        _smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 12, wordWrap = true };
        _valueStyle = new GUIStyle(GUI.skin.label) { fontSize = 16, alignment = TextAnchor.MiddleLeft };
        _inputStyle = new GUIStyle(GUI.skin.textField) { fontSize = 16, alignment = TextAnchor.MiddleLeft };
        _buttonStyle = new GUIStyle(GUI.skin.button) { fontSize = 14 };
        _titleStyle.normal.textColor = Color.white;
        _bodyStyle.normal.textColor = Color.white;
        _smallStyle.normal.textColor = new Color(0.77f, 0.83f, 0.88f);
        _valueStyle.normal.textColor = Color.white;
    }

    [HideFromIl2Cpp]
    private static bool IsKeyDown(int key) => (GetAsyncKeyState(key) & 0x8000) != 0;

    [HideFromIl2Cpp]
    private static bool IsGameFocused()
    {
        IntPtr window = GetForegroundWindow();
        if (window == IntPtr.Zero) return false;
        GetWindowThreadProcessId(window, out uint pid);
        return pid == Environment.ProcessId;
    }

    [DllImport("user32.dll")]
    [HideFromIl2Cpp]
    private static extern short GetAsyncKeyState(int virtualKey);
    [DllImport("user32.dll")]
    [HideFromIl2Cpp]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    [HideFromIl2Cpp]
    private static extern uint GetWindowThreadProcessId(IntPtr handle, out uint processId);
}
