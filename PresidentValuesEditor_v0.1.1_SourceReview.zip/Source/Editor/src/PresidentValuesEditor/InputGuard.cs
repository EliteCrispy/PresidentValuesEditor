using System;
using System.Collections.Generic;
using Features.Day;
using Il2CppInterop.Runtime;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;
using Cursor = UnityEngine.Cursor;
using UnityObject = UnityEngine.Object;

namespace PresidentValuesEditor;

/// <summary>
/// Owns one editor session's clock pause and input suppression. All methods must
/// run on Unity's main thread. It deliberately leaves Time.timeScale untouched.
/// </summary>
internal sealed class InputGuard : IDisposable
{
    private readonly DayService _day;
    private readonly string _pauseReason = Plugin.Id + ".inputguard." + Guid.NewGuid().ToString("N");
    private readonly List<PlayerInput> _activeInputs = new();
    private readonly List<PresidentSim.Player> _enabledPlayers = new();
    private readonly List<BaseInputModule> _enabledInputModules = new();
    private readonly List<EventSystem> _enabledEventSystems = new();
    private readonly List<DocumentSnapshot> _enabledDocumentRoots = new();

    private bool _acquireStarted;
    private bool _acquired;
    private bool _disposed;
    private bool _pauseRequested;
    private bool _cursorCaptured;
    private bool _cursorWarningReported;
    private CursorLockMode _previousCursorLock;
    private bool _previousCursorVisible;

    internal InputGuard(DayService day)
    {
        _day = day ?? throw new ArgumentNullException(nameof(day));
    }

    public void Acquire()
    {
        if (_disposed)
            throw new ObjectDisposedException(nameof(InputGuard));
        if (_acquired)
            return;
        if (_acquireStarted)
            throw new InvalidOperationException("InputGuard acquisition is already in progress.");

        _acquireStarted = true;
        try
        {
            _previousCursorLock = Cursor.lockState;
            _previousCursorVisible = Cursor.visible;
            _cursorCaptured = true;

            // Record ownership before calling a publisher: a subscriber could
            // throw after the day controller has already accepted our reason.
            _pauseRequested = true;
            _day.Pause(_pauseReason, true);

            foreach (PlayerInput input in FindAll<PlayerInput>())
            {
                if (!input.isActiveAndEnabled || !input.inputIsActive)
                    continue;

                _activeInputs.Add(input);
                // This preserves currentActionMap and device pairing. Toggling
                // the PlayerInput component itself has broader side effects.
                input.DeactivateInput();
            }

            foreach (PresidentSim.Player player in FindAll<PresidentSim.Player>())
            {
                if (!player.enabled)
                    continue;

                _enabledPlayers.Add(player);
                // Player.Update also performs targeting and changes the cursor;
                // turning off the action map alone does not stop those paths.
                player.enabled = false;
            }

            foreach (BaseInputModule module in FindAll<BaseInputModule>())
            {
                if (!module.enabled)
                    continue;

                _enabledInputModules.Add(module);
                // InputSystemUIInputModule.OnDisable clears pending pointers.
                module.enabled = false;
            }

            foreach (EventSystem eventSystem in FindAll<EventSystem>())
            {
                if (!eventSystem.enabled)
                    continue;

                _enabledEventSystems.Add(eventSystem);
                eventSystem.enabled = false;
            }

            foreach (UIDocument document in FindAll<UIDocument>())
            {
                VisualElement root = document.rootVisualElement;
                if (root == null || !root.enabledSelf)
                    continue;

                _enabledDocumentRoots.Add(new DocumentSnapshot(document, root.Pointer));
                // Disabling UIDocument itself can rebuild the visual tree. Its
                // root's enabled state blocks controls without replacing it.
                root.SetEnabled(false);
            }

            SetCursorFree();
            _acquired = true;
        }
        catch
        {
            // Every mutation is recorded before it is attempted, so cleanup
            // also covers a native call that changed state before throwing.
            Dispose();
            throw;
        }
    }

    public void KeepCursorFree()
    {
        if (!_acquired || _disposed)
            return;

        try
        {
            SetCursorFree();
        }
        catch (Exception error)
        {
            if (!_cursorWarningReported)
            {
                _cursorWarningReported = true;
                Warn("keeping the editor cursor available", error);
            }
        }
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _disposed = true;
        _acquired = false;

        // Restore only the objects and states this instance changed. Never
        // discover new objects during cleanup, especially across scene unloads.
        for (int index = _enabledDocumentRoots.Count - 1; index >= 0; --index)
        {
            DocumentSnapshot snapshot = _enabledDocumentRoots[index];
            Attempt("restoring a UI Toolkit document", () =>
            {
                if (!Exists(snapshot.Document))
                    return;

                VisualElement root = snapshot.Document.rootVisualElement;
                if (root != null && root.Pointer == snapshot.RootPointer)
                    root.SetEnabled(true);
            });
        }
        _enabledDocumentRoots.Clear();

        for (int index = _enabledInputModules.Count - 1; index >= 0; --index)
        {
            BaseInputModule module = _enabledInputModules[index];
            Attempt("restoring a UI input module", () =>
            {
                if (Exists(module))
                    module.enabled = true;
            });
        }
        _enabledInputModules.Clear();

        for (int index = _enabledEventSystems.Count - 1; index >= 0; --index)
        {
            EventSystem eventSystem = _enabledEventSystems[index];
            Attempt("restoring an event system", () =>
            {
                if (Exists(eventSystem))
                    eventSystem.enabled = true;
            });
        }
        _enabledEventSystems.Clear();

        for (int index = _enabledPlayers.Count - 1; index >= 0; --index)
        {
            PresidentSim.Player player = _enabledPlayers[index];
            Attempt("restoring the player controller", () =>
            {
                if (Exists(player))
                    player.enabled = true;
            });
        }
        _enabledPlayers.Clear();

        for (int index = _activeInputs.Count - 1; index >= 0; --index)
        {
            PlayerInput input = _activeInputs[index];
            Attempt("restoring player input", () =>
            {
                // An inactive or disabled component may now belong to an
                // unloaded scene or another game context; leave it alone.
                if (Exists(input) && input.isActiveAndEnabled && !input.inputIsActive)
                    input.ActivateInput();
            });
        }
        _activeInputs.Clear();

        if (_pauseRequested)
        {
            _pauseRequested = false;
            Attempt("releasing the editor's clock pause", () => _day.Pause(_pauseReason, false));
        }

        if (_cursorCaptured)
        {
            _cursorCaptured = false;
            // Keep these separate so failure of one does not skip the other.
            Attempt("restoring cursor lock", () => Cursor.lockState = _previousCursorLock);
            Attempt("restoring cursor visibility", () => Cursor.visible = _previousCursorVisible);
        }
    }

    private static IEnumerable<T> FindAll<T>() where T : UnityObject
    {
        foreach (UnityObject value in UnityObject.FindObjectsOfType(Il2CppType.Of<T>(), true))
        {
            if (Exists(value))
                yield return value.Cast<T>();
        }
    }

    private static bool Exists(UnityObject value)
    {
        // Unity's equality operator also checks whether the native object was
        // destroyed; a managed wrapper alone can survive a scene unload.
        return value != null;
    }

    private static void SetCursorFree()
    {
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private static void Attempt(string action, Action cleanup)
    {
        try
        {
            cleanup();
        }
        catch (Exception error)
        {
            Warn(action, error);
        }
    }

    private static void Warn(string action, Exception error)
    {
        try
        {
            Plugin.LogSink.LogWarning($"Values editor: error while {action}: {error}");
        }
        catch
        {
            // Logging must never prevent the remaining cleanup operations.
        }
    }

    private sealed class DocumentSnapshot
    {
        internal DocumentSnapshot(UIDocument document, IntPtr rootPointer)
        {
            Document = document;
            RootPointer = rootPointer;
        }

        internal UIDocument Document { get; }
        internal IntPtr RootPointer { get; }
    }
}
