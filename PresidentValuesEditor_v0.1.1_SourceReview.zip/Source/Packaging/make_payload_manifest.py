"""Generate the exact allow-list after the parent finishes assembling Payload/."""
from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument('package_root', type=Path)
parser.add_argument('--version', default='0.1.0')
args = parser.parse_args()
payload = args.package_root / 'Payload'
files = []
for path in sorted(payload.rglob('*')):
    if path.is_symlink():
        raise SystemExit(f'Unexpected payload symlink: {path}')
    if not path.is_file():
        continue
    relative = path.relative_to(payload).as_posix()
    if not (relative.startswith(('BepInEx/', 'dotnet/')) or relative in ('winhttp.dll', 'doorstop_config.ini', '.doorstop_version')):
        raise SystemExit(f'Unexpected payload path: {relative}')
    files.append({'Path': relative, 'Bytes': path.stat().st_size, 'SHA256': hashlib.sha256(path.read_bytes()).hexdigest().upper()})
required = {'winhttp.dll', 'doorstop_config.ini', 'BepInEx/plugins/PresidentValuesEditor/PresidentValuesEditor.dll'}
if not required.issubset({f['Path'] for f in files}):
    raise SystemExit('Required loader/editor files are missing')
manifest = {'Format': 1, 'Product': 'PresidentSimulatorValuesEditor', 'ModVersion': args.version,
            'TargetAppId': '3705900', 'TargetBuildId': '26325310', 'Files': files}
target = args.package_root / 'PayloadManifest.json'
target.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(f'{len(files)} files, {sum(f["Bytes"] for f in files)} bytes: {target}')
